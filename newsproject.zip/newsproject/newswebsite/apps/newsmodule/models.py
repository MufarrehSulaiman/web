from django.db import models

class mobiles(models.Model):
 Mobile_Name = models.CharField(max_length = 50)
 Brand = models.CharField(max_length = 50)
 OS = models.CharField(max_length=50)
 Mobile_Date = models.IntegerField(default = 0)
 
 
 class Car(models.Model):
  Car_Name = models.CharField(max_length = 50)
  Brand = models.CharField(max_length = 50)
  Car_Module = models.IntegerField(default = 0)