
from django.shortcuts import render, redirect
from .models import mobiles


def index(request):
# render the appropriate template for this request
   return render(request, 'newsmodule/index.html')

def Economy(request):
# render the appropriate template for this request
   return render(request, 'newsmodule/Economy.html')

def Games(request):
# render the appropriate template for this request
   return render(request, 'newsmodule/Games.html')

def mobile (request):
   mobile = mobiles.objects.filter(OS__contains='And').order_by('Mobile_Date') 
# render the appropriate template for this request
   return render(request, 'newsmodule/mobiles.html', {'mobile':mobile})

def Health(request):
# render the appropriate template for this request
   return render(request, 'newsmodule/Health.html')

def news(request):
   return render(request,'newsmodule/news.html', {'news':get_Clubs()})

def news_Sport(request,a):

   n1 = {'id':1, 'name': ' Al-Nassr','Founded':' 1955','Stadium':' Al-Awwal Park' }
   n2 = {'id':2, 'name':' Liverpool','Founded':' 1892','Stadium':' Anfield'}
   terget_n= None
   
   if n1 ['id'] == a: terget_n = n1
   if n2 ['id'] == a: terget_n = n2
   if terget_n == None: return redirect('/news')
   context ={'new': terget_n}
   return render (request,'newsmodule/news_Sport.html', context)
   
def get_Clubs():
   news=[]
   n1 = {'id':1, 'name': ' Al-Nassr','Founded':' 1955','Stadium':' Al-Awwal Park' }
   n2 = {'id':2, 'name':' Liverpool','Founded':' 1892','Stadium':' Anfield'}  
   
   news.append(n1)
   news.append(n2)
   return news