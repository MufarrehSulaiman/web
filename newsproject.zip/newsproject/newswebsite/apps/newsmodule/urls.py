from django.urls import path, include
from apps.newsmodule import views

urlpatterns = [
path('', views.index,name='index'),
path('Economy', views.Economy,name='Economy'),
path('Games', views.Games,name='Games'),
path('Health', views.Health,name='Health'),
path('mobiles', views.mobile,name='mobile'),
path('news', views.news,name='news'),
path('news_Sport/<int:a>', views.news_Sport)   
 
   
]


